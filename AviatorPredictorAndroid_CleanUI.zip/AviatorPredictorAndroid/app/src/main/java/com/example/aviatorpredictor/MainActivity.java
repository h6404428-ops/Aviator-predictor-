package com.example.aviatorpredictor;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, historyBox;
    EditText input;
    TextView signal, range, stats, statusDot;
    ArrayList<Double> rounds = new ArrayList<>();
    final int bg=Color.rgb(9,12,17), panel=Color.rgb(20,25,34), panel2=Color.rgb(27,33,44);
    final int white=Color.rgb(245,247,250), muted=Color.rgb(160,170,185), accent=Color.rgb(255,193,7);
    final int green=Color.rgb(54,211,122), red=Color.rgb(255,82,82), yellow=Color.rgb(255,193,7);

    @Override public void onCreate(Bundle b){ super.onCreate(b); build(); seed(); analyze(); }

    TextView tv(String s,float size){ TextView t=new TextView(this); t.setText(s); t.setTextColor(white); t.setTextSize(size); t.setPadding(14,10,14,10); return t; }
    GradientDrawable bg(int color,float radius){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g; }
    Button btn(String s){ Button b=new Button(this); b.setText(s); b.setTextColor(Color.BLACK); b.setTextSize(14); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setAllCaps(false); b.setBackground(bg(accent,22)); return b; }
    TextView cardText(String s,float size){ TextView t=tv(s,size); t.setBackground(bg(panel2,22)); return t; }

    void build(){
        ScrollView sc=new ScrollView(this); sc.setFillViewport(true);
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(18,16,18,28); root.setBackgroundColor(bg); sc.addView(root); setContentView(sc);

        LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL); head.setPadding(4,4,4,12);
        TextView logo=tv("✈",34); logo.setTextColor(accent); head.addView(logo,new LinearLayout.LayoutParams(52,64));
        LinearLayout ht=new LinearLayout(this); ht.setOrientation(LinearLayout.VERTICAL);
        TextView title=tv("AVIATOR",26); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); title.setTextColor(white); ht.addView(title);
        TextView sub=tv("SIGNAL ANALYZER",12); sub.setTextColor(muted); ht.addView(sub);
        head.addView(ht,new LinearLayout.LayoutParams(0,64,1));
        statusDot=tv("● LIVE ANALYSIS",12); statusDot.setTextColor(green); statusDot.setGravity(Gravity.CENTER); head.addView(statusDot,new LinearLayout.LayoutParams(120,50));
        root.addView(head);

        TextView note=tv("Uses recent round history for statistical signals. It cannot know the next crash point.",12); note.setTextColor(muted); note.setGravity(Gravity.CENTER); note.setPadding(8,4,8,16); root.addView(note);

        LinearLayout signalCard=new LinearLayout(this); signalCard.setOrientation(LinearLayout.VERTICAL); signalCard.setPadding(18,18,18,18); signalCard.setGravity(Gravity.CENTER); signalCard.setBackground(bg(panel,28));
        TextView cap=tv("CURRENT SIGNAL",12); cap.setTextColor(muted); cap.setGravity(Gravity.CENTER); signalCard.addView(cap);
        signal=tv("ANALYZING…",24); signal.setTypeface(Typeface.DEFAULT,Typeface.BOLD); signal.setGravity(Gravity.CENTER); signalCard.addView(signal,new LinearLayout.LayoutParams(-1,58));
        range=tv("Reference range: —",15); range.setTextColor(white); range.setGravity(Gravity.CENTER); signalCard.addView(range);
        root.addView(signalCard,new LinearLayout.LayoutParams(-1,180));

        TextView st=tv("STATISTICS",13); st.setTextColor(muted); st.setPadding(4,20,4,8); root.addView(st);
        stats=cardText("",15); stats.setPadding(18,16,18,16); root.addView(stats,new LinearLayout.LayoutParams(-1,140));

        TextView ent=tv("ADD LAST ROUND",13); ent.setTextColor(muted); ent.setPadding(4,20,4,8); root.addView(ent);
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        input=new EditText(this); input.setHint("e.g. 1.72"); input.setHintTextColor(muted); input.setTextColor(white); input.setTextSize(17); input.setSingleLine(true); input.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL); input.setPadding(16,0,16,0); input.setBackground(bg(panel2,22));
        row.addView(input,new LinearLayout.LayoutParams(0,58,1));
        Button add=btn("ADD ROUND"); LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(130,58); ap.setMargins(10,0,0,0); row.addView(add,ap); add.setOnClickListener(v->addRound()); root.addView(row);

        LinearLayout actions=new LinearLayout(this); actions.setGravity(Gravity.CENTER); Button clear=btn("Clear history"); clear.setTextColor(white); clear.setBackground(bg(panel2,22)); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(150,52); cp.setMargins(0,14,0,8); actions.addView(clear,cp); clear.setOnClickListener(v->{rounds.clear(); analyze();}); root.addView(actions);

        TextView rh=tv("RECENT ROUNDS",13); rh.setTextColor(muted); rh.setPadding(4,10,4,8); root.addView(rh);
        historyBox=new LinearLayout(this); historyBox.setOrientation(LinearLayout.VERTICAL); root.addView(historyBox);

        TextView foot=tv("For analysis only • No guaranteed predictions • Play responsibly",11); foot.setTextColor(muted); foot.setGravity(Gravity.CENTER); foot.setPadding(8,22,8,0); root.addView(foot);
    }

    void seed(){ double[] a={5.74,1.11,1.08,1.34,2.06,2.04,1.02}; for(double x:a) rounds.add(x); }
    void addRound(){ try{ String s=input.getText().toString().trim().toLowerCase(Locale.US).replace("x",""); double x=Double.parseDouble(s); if(x<1) throw new Exception(); rounds.add(0,x); if(rounds.size()>50) rounds.remove(rounds.size()-1); input.setText(""); analyze(); } catch(Exception e){ Toast.makeText(this,"Enter a valid multiplier, e.g. 1.50",Toast.LENGTH_SHORT).show(); } }

    void analyze(){
        historyBox.removeAllViews();
        for(int i=0;i<rounds.size();i++){ TextView t=tv(String.format(Locale.US,"%02d     %.2fx",i+1,rounds.get(i)),15); t.setTextColor(rounds.get(i)>=2.5?accent:white); t.setBackground(bg(panel2,16)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,48); p.setMargins(0,0,0,6); historyBox.addView(t,p); }
        if(rounds.isEmpty()){ signal.setText("NO DATA"); signal.setTextColor(muted); range.setText("Add recent rounds"); stats.setText("No rounds entered yet."); statusDot.setText("● WAITING"); statusDot.setTextColor(muted); return; }
        int n=Math.min(12,rounds.size()); double sum=0,sq=0; int low=0,mid=0,high=0; ArrayList<Double>a=new ArrayList<>();
        for(int i=0;i<n;i++){ double x=rounds.get(i); a.add(x); sum+=x; if(x<1.5)low++; else if(x<2.5)mid++; else high++; }
        double avg=sum/n; for(double x:a)sq+=(x-avg)*(x-avg); double sd=Math.sqrt(sq/n); Collections.sort(a); double med=(n%2==1)?a.get(n/2):(a.get(n/2-1)+a.get(n/2))/2.0; double ref=Math.max(1.05,Math.min(3.0,(avg+med)/2));
        String s; int c; if(low>=8){s="CAUTION • LOW CLUSTER";c=yellow;} else if(high>=5){s="CAUTION • HIGH VOLATILITY";c=yellow;} else if(sd>1.5){s="WAIT • HIGH VOLATILITY";c=red;} else {s="MONITOR • NO CLEAR PATTERN";c=green;}
        signal.setText(s); signal.setTextColor(c); statusDot.setText("● ANALYZING"); statusDot.setTextColor(green);
        range.setText(String.format(Locale.US,"Reference range: %.2fx – %.2fx",Math.max(1.01,ref*.75),ref*1.25));
        stats.setText(String.format(Locale.US,"Last %d rounds\nAverage       %.2fx\nMedian        %.2fx\nLow <1.50x    %d     Mid 1.50–2.49x  %d     High ≥2.50x  %d\nVolatility     %.2f SD",n,avg,med,low,mid,high,sd));
    }
}
