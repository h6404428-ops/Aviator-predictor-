# Aviator Predictor — Android Project

Clean dark Aviator-style statistical signal analyzer UI.

## Build
Open the project in Android Studio and build the debug APK.

## Phone-only online build
Upload this ZIP to an Android project build service that supports Gradle/Android Studio projects. The output should be an APK.

## Important
This app analyzes recent multipliers only. Crash-game outcomes are not reliably predictable; the signal is not a guaranteed prediction or betting instruction.
